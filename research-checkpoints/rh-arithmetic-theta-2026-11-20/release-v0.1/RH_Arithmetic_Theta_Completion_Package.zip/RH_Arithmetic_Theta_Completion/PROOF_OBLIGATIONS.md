# Proof-obligation register

**Companion to:** *The Twin-Ladder Weil Form and an Arithmetic Theta Completion Route*  
**Date:** 20 November 2026  
**Current status:** The analytic transfer statements are proved in the manuscript. The arithmetic completion below is open. This register is not an RH proof and does not certify the announced external proof.

## 1. Choose an exact completion interface

There are three useful interfaces. Proving any one with its full hypotheses would complete the corresponding analytic route. A construction need not prove all three. It must say which target it actually supplies.

### Interface A: fixed-prefix Weil/Gram comparison

Fix

\[
F(w)=\xi(1/2+w),\quad L=F'/F,\quad
x_j=1+\frac1{j+1}\quad(j\ge1),\quad
v_b(t)=\sum_{j=1}^n b_j e^{-x_jt}.
\]

Let \(P_n\) have entries \((L(x_i)+L(x_j))/(x_i+x_j)\). Let \(Q_{L,X}(v_b)=b^*P_{X,n}b\) retain the exact gamma and pole terms and truncate only the prime sum at integer \(X\ge3\).

**Open target A.** For each fixed positive integer \(n\), construct arithmetic data yielding Hermitian matrices \(G_{X,n}\) and nonnegative errors such that

\[
P_{X,n}-G_{X,n}\succeq-\epsilon_{X,n}I_n,
\qquad G_{X,n}\succeq-\eta_{X,n}I_n,
\qquad \epsilon_{X,n}+\eta_{X,n}\longrightarrow0.
\tag{A}
\]

An exact positive Hilbert-space realization has \(G_{X,n}=T_{X,n}^*T_{X,n}\) and \(\eta_{X,n}=0\). In vector notation, with the inner product conjugate-linear in its first argument, the required comparison is

\[
Q_{L,X}(v_b)\ge
\left\|\sum_{j=1}^n b_j\Theta_{X,j}\right\|^2
-\epsilon_{X,n}\|b\|_2^2
\quad\text{for every }b\in\mathbb C^n.
\tag{A'}
\]

The completed prime tail is already controlled. Writing \(x_* =\min_{j\le n}x_j\) and \(\delta=x_*-1/2>0\), the manuscript proves

\[
\|P_n-P_{X,n}\|\le
r_n(X):=\frac{n}{x_*}X^{-\delta}
\left(\frac{\log X}{\delta}+\frac1{\delta^2}\right)\longrightarrow0.
\]

Thus (A) gives \(b^*P_nb\ge-[r_n+\epsilon_{X,n}+\eta_{X,n}]\|b\|^2\). Taking \(X\to\infty\) for fixed \(n,b\) proves \(P_n\succeq0\). The sparse-prefix theorem then gives RH.

**Exact quantifiers.** Every finite \(n\) is required; its own convergence rate is enough. There is no requirement of a uniform lower eigenvalue bound, a fixed spectral gap, or an error uniform in all matrix sizes. An estimate must nevertheless control every complex coefficient vector in the fixed prefix. Diagonal tests or a positive-coefficient cone are insufficient. Pointwise limiting inequalities for every fixed vector would also suffice, but a matrix bound makes the finite-dimensional quantifier explicit.

The zero map is not a shortcut: choosing all \(\Theta_{X,j}=0\) leaves exactly the open lower bound for \(Q_{L,X}\). Defining vectors through an assumed positive spectral decomposition of \(P_n\), or taking a positive part and assuming its negative part is small, similarly conceals the target.

### Interface B: a full-ray scalar estimate

Use the exact discrepancy

\[
G_\zeta(X)=\sum_{m\le X}\Lambda(m)(X/m-1)
-X\log X+(1+\gamma_E)X,\qquad X\ge1.
\]

**Open target B.** Choose one fixed sign \(\varepsilon_0\in\{1,-1\}\) and prove

\[
\forall\varepsilon>0\ \exists C_\varepsilon,X_\varepsilon\quad
\varepsilon_0G_\zeta(X)\le C_\varepsilon X^{1/2+\varepsilon}
\quad\forall X\ge X_\varepsilon.
\tag{B}
\]

The manuscript supplies a complete Mellin/Landau implication from (B) to RH. Its transform is

\[
\int_1^\infty G_\zeta(X)X^{-s-1}\,dX
=\frac{-\zeta'(s)/\zeta(s)}{s(s-1)}
-\frac1{(s-1)^2}+\frac{1+\gamma_E}{s-1},\quad\Re s>1.
\]

The main terms remove the apparent pole at 1; a nontrivial zero leaves a nonzero residue. The hard new theorem would be (B), not this transform calculation. A bound along an unspecified sequence of isolated \(X\)'s does not meet (B). A proof first stated at integer arguments must supply the extension to all sufficiently large real \(X\).

### Interface C: the external multiplicative-window theorem

The released source states a more delicate implication for a fixed finite admissible family of Dirichlet characters with fixed strictly positive weights. For each member the discrepancy uses the source's exact pole correction; the principal modulus-one member uses \(G_\zeta\) above. Write their weighted real sum as \(G_{\mathcal F}\).

**Open/import target C.** For fixed \(0<\theta<1\), \(\delta_0>0\) and \(C\), prove

\[
\forall Y_0\ \exists Y\ge Y_0\quad
G_{\mathcal F}(y)\le Cy^\theta
\quad\forall y\in[Y,Y^{1+\delta_0}],
\tag{C}
\]

and validate the exact external theorem and dependencies taking (C) to zero-freeness to the right of \(\theta\). To reach RH, the exponents and families must imply exclusion of every zero with real part greater than one half. The family and weights must be fixed before choosing the windows; changing them with each point is a different statement. The estimate must hold throughout each entire multiplicative window with the stated common constants.

This package's full-ray Landau proof does not prove the window implication. The latter is an **EXTERNAL SOURCE STATEMENT**, pinned in the evidence ledger. It becomes a usable proof input only after its load-bearing dependency chain is validated or an independent proof is supplied.

## 2. Arithmetic data that a definite theta-lift construction must supply

The old obstruction concerns a realization covariant under a **mixing** unitary flow. PR 61's referee leaves compact or definite targets, Hecke/Casimir evolution, source-side test insertion, and noncovariant/truncated constructions unexcluded. This supplies a precise place to investigate the announced approach, not the existence of a map.

For a proposed construction, the following are mathematical specifications, not optional presentation details:

| Obligation | Data to give | Criterion for completion |
|---|---|---|
| D1. Underlying spaces | The number field, definite quadratic or Hermitian spaces, signatures at every archimedean place, dimensions/ranks and discriminants. | The spaces and their dependence on \(X,n\) are unambiguous; positivity is proved on the actual target. |
| D2. Groups and measures | The orthogonal/unitary/metaplectic groups, covers if any, arithmetic quotients, levels, Haar/Petersson measures and normalizations. | Every norm and comparison uses compatible measures; scale factors are computed. |
| D3. Starting representation | The initial automorphic representation, inducing characters, central character, ramification, local components and archimedean factors. | Existence, nonvanishing and all needed bounds are proved without RH or the desired positivity. |
| D4. Test insertion | The vector corresponding to each exponential rate \(x_j\), or the scalar/window test, and how complex linear combinations enter. | There is one specified linear map on the full fixed test space, not a separate favorable choice for each coefficient vector. If a different nonlinear formulation is used, its exact all-vector inequality must be proved directly. |
| D5. Lift chain | Every theta kernel, input/output pair, lift operator, branching choice and chain length \(m(X)\). | Convergence, regularization, nonzero output when needed, and the dependence on all parameters are established. |
| D6. Arithmetic divisibility | The integral lattices/modules, denominators, ideals and local integrality assertions used in the Stepanov-inspired step. | The claimed multiplicity/divisibility gain is a theorem in characteristic zero with quantified losses; a function-field analogy alone is insufficient. |
| D7. Family averaging | The Hecke/Dirichlet characters, conductor range, weights, multiplicities and orthogonality formula. | Exceptional, ramified and boundary terms are included; the family satisfies the chosen interface's quantifiers. |

No positive-definite norm may be inferred simply from the word “definite” without specifying the space, convergence and actual form. No ordinary finite-dimensional Gram construction can remove the arithmetic matching requirement below.

## 3. The central open matching theorem

For Interface A, the comparison must recover the full signed form. In the manuscript's notation,

\[
\begin{aligned}
Q_L(v)={}&E_\gamma(v)+|J_{-1/2}(0)|^2-\|J_{-1/2}\|_2^2
-2c_0\|v\|_2^2\\
&-2\sum_{m\ge2}\frac{\Lambda(m)}{\sqrt m}\Re C_v(\log m),
\end{aligned}
\]

where

\[
c_0=\tfrac12(\log\pi-\psi(5/4)),\quad
\lambda_k=2k+\tfrac52,\quad
J_\lambda(t)=\sum_j\frac{b_je^{-x_jt}}{x_j+\lambda},\quad
H_\lambda=v-\lambda J_\lambda,
\]

\[
E_\gamma(v)=\sum_{k\ge0}\left(|J_{\lambda_k}(0)|^2+
\frac2{\lambda_k}\|H_{\lambda_k}\|_2^2\right),\qquad
C_v(\ell)=\int_0^\infty v(t+\ell)\overline{v(t)}\,dt.
\]

**M1. Prove an identity or the correct lower inequality.** A candidate must establish (A) or (A') with this form, retaining the full gamma contribution, both pole terms, the completed normalization and every prime power. A positive lift norm with an unrelated diagonal, trace, moment or Euler product does not establish this inequality. An upper bound on \(Q_L\) is the wrong direction.

**M2. Identify the test transformation.** The Mellin convention here is \(f(y)=y^{-1/2}v(-\log y)1_{(0,1]}(y)\), with transform \(\widetilde f(s)=V(s-1/2)\). Centered zeros of \(F\) and ordinary zeros of \(\zeta\) differ by one half. Conjugation is \(V(\rho)\overline{V(-\bar\rho)}\), becoming a square only after the desired zero-location assertion. Any automorphic functional equation, Fourier convention or involution must be reconciled explicitly with these choices.

**M3. Control off-diagonal correlations.** It is not enough to match \(Q_L(e^{-x_jt})\) for individual rates. Polarization must recover mixed entries and arbitrary complex combinations. If error is stated entrywise, it must imply the fixed-prefix quadratic-form bound, with the dimension factor shown.

**M4. Keep imported estimates at their actual scale.** The released `LinkS` proposition contains dimension-normalized off-diagonal and diagonal Hilbert–Schmidt controls with explicit comparability assumptions. An example scale is

\[
\operatorname{hsSq}(u,u')\le(1+\eta_0)\frac{d_ud_{u'}}{D_*},\qquad
C_0^{-1}\le\frac{d_u\Gamma^2}{D_*}\le C_0.
\]

The reference quantity need not tend to zero. A small relative parameter in that formula is not already a small absolute error in (A). An intertwiner, norm conversion and all dimension factors are required before calling it a bound on \(B^*D^{-1}B\) or the project's Pick defect.

**M5. Avoid circular dependencies.** Identify where exact multiplicativity, the completed functional equation and arithmetic divisibility actually enter. Do not assume RH, positivity of the same Weil/Pick kernel, a Hilbert-space completion whose positivity is the target, or an external endpoint already asserting RH to prove the matching lemma. An endpoint import can be legitimate exposition, but must be labeled as such.

## 4. Accumulated cost when the chain has length about square root of X

The inspected source's `SizeWindows` condition uses \(X^{1/2-\varepsilon}\le m\le X^{1/2+\varepsilon/2}\), along with other quantitative hypotheses. The manuscript independently proves the downstream algebra of `GrowthSizeBound` in Proposition 5.4. A proof must construct data satisfying the complete window, balance inequality and total error bound. The illustrative stability examples below use \(m\asymp\sqrt X\); that simplified model is not substituted for the source's exact range.

**C1. Normalize before counting gains.** Track how each lift changes level/conductor, rank, dimension, volume, local denominators, vector norms and the scale of the final arithmetic quantity. A divisibility gain may be canceled by a denominator or volume factor if these are not recorded in the same normalization.

**C2. Propagate errors through later lifts.** If the actual recurrence gives normalized operator bounds \(\|T_j\|\le A_j\) and additive form errors \(\delta_j\), a typical sufficient stability estimate has the shape

\[
E_{X,n}\le E^{\rm tail}_{X,n}+E^{\rm boundary}_{X,n}
+E^{\rm local}_{X,n}
+\sum_{j=1}^{m(X)}\delta_{j,X,n}
\prod_{k=j+1}^{m(X)}A_{k,X,n}^{\,2}.
\tag{Cost}
\]

This displayed formula is an example of the required bookkeeping, not an asserted bound for any unconstructed theta chain. The proposed chain must derive its own propagation inequality. Correlations between errors, regularization terms and changes of basis also require control; they may not be silently treated as independent or canceled.

For scale: if each \(A_j\le1+c/m\), the products in (Cost) are bounded by \(e^{2c}\), so a uniform per-step error \(o(1/m)\) would make the accumulated sum tend to zero. With \(m\asymp\sqrt X\), a per-step \(O(X^{-1})\) error would sum to \(O(X^{-1/2})\) under that stable normalization. A fixed amplification \(A_j>1\) instead gives possible growth exponential in \(\sqrt X\). These elementary examples explain why a per-stage saving alone does not settle the required estimate.

**C3. State the final asymptotic at the chosen interface.** For A, establish \(E_{X,n}=o_n(1)\) after normalization to \(\|b\|_2^2\), for every fixed \(n\). No stronger uniform spectral gap is required. For B, establish the full-ray one-sided \(X^{1/2+\varepsilon}\) bound with constants allowed to depend on \(\varepsilon\). For C, establish the bound throughout the specified windows, with the family and constants fixed as stated. The conversion from a lift norm or dimension estimate to one of these outputs must be displayed.

**C4. Account for all exceptional contributions.** Include noncuspidal or residual terms, ramified places, vanishing lifts, oldforms/multiplicities, missing prime powers, archimedean tails, window endpoints and regularization boundaries whenever present in the actual construction. An assertion that these are harmless requires a quantitative bound compatible with C3.

## 5. Domains, singular prefixes and limits

**L1. Stay within justified domains.** Prime expansions here converge absolutely for rates greater than one half. A lift formula requiring compact support, smoothness, cusp conditions or square integrability must be applied on its stated domain. The one-sided Mellin test has a boundary corner. If approximation is used, specify cutoffs/mollifiers and prove convergence of the relevant signed form and lift norms. Do not use an unproved closability or density statement to pass to a larger space.

**L2. Use the correct singular Schur criterion if following residual induction.** For a PSD prefix \(A\), the next block is PSD exactly when

\[
u\in\operatorname{ran}A,\qquad d-u^*A^\dagger u\ge0.
\]

An inverse residual is undefined for a singular prefix, and a nonnegative pseudoinverse defect alone is insufficient. Interface A avoids this induction issue by establishing the whole finite matrix inequality directly.

**L3. Keep the order of limits explicit.** First fix \(n\) and the coefficient vector, then let the arithmetic/truncation parameter tend to infinity. Only afterward use the assertion for every \(n\). The interpolation theorem uses an interior accumulation point and a normal-family limit; it does not require a uniform inverse bound for the prefixes. A finite list of successful sizes cannot replace the universal assertion.

**L4. Do not identify different operators by analogy.** The annulus reference, theta cutoff, odd Mellin form, global Weil form, finite-cluster trace form and windowed zero form have different domains and spectra unless an intertwiner is proved. The later `sq-krein-index` lane does assert a broader distinct-zero inertia result, but it is unrefereed and was not validated here. The earlier audited finite-cluster theorem cannot be silently promoted using that later assertion.

## 6. Evidence needed before marking a completion theorem proved

The completed argument should have a short load-bearing dependency graph:

1. A specified arithmetic construction meeting D1–D7 where applicable.
2. A proved matching theorem M1–M5, or an exact derivation of scalar/window target B/C.
3. The quantitative whole-chain cost bound C1–C4.
4. Valid domains and limiting arguments L1–L4.
5. The existing analytic transfer theorem, with every imported theorem's actual hypotheses checked.

The existing project controls should be used to find where the proposed proof relies on the real arithmetic: an off-axis even positive-kernel deformation, Davenport–Heilbronn, and perturbations of prime weights each defeat particular generic arguments. A control need not share assumptions it manifestly lacks. In particular, the prime-weight perturbation in PR 60 generally loses the functional equation; its failure cannot be advertised as a counterexample to the full exact arithmetic package. Passing such controls is a diagnostic safeguard, not a proof of the universal estimate.

For a formal-source import, record the source commit, theorem identifier, complete theorem type, toolchain and dependency versions, and the actual successful build or kernel replay of the load-bearing theorem. Distinguish a proposition definition, a theorem conditional on that proposition, and a construction proving the proposition. A source scan, verification-harness smoke test or compiling endpoint statement does not verify the dependency chain. The present package records the reported archive hash and source pin but has not performed the full external replay.

## 7. Current open frontier

The next mathematical result should be a concrete lower-level transport inequality from a specified definite theta-lift chain to (A), or a complete costed proof of (B)/(C). PR 61's compact/definite exception makes that class worth examining, and its later metaplectic and rank-two work provides relevant partial structure and known failures. It does not already provide the required chain or estimate. More finite Pick stages, a stronger finite zero certificate, or a different geometric drawing cannot substitute for this missing theorem.

Until one of these interfaces is proved without circular input, the proper release description remains **exact reductions and a conditional completion route**.
