# The twin-ladder Weil form and an arithmetic theta completion route

Jude Gomila — research manuscript v0.1, 20 November 2026.

## Current mathematical result

This package contains a complete analytic reduction and a source-based comparison of the accumulated RH program with Alpöge's announced arithmetic theta-lift route. It does **not** contain an unconditional proof of RH. The missing arithmetic comparison is stated explicitly in the manuscript and PROOF_OBLIGATIONS.md.

The proved transfer result reduces the task to asymptotically positive arithmetic Gram comparisons for the prefixes of one fixed sequence of rates, x_j = 1 + 1/(j+1). Each fixed matrix size may have its own error bound. No uniform positive spectral gap and no uniformity in the matrix size are required. The condition must nevertheless be established for every finite size.

The manuscript also derives the exact signed gamma–pole–prime form, a quantitative prime tail, the one-sided weighted Mangoldt Mellin transform and a full-ray sufficient estimate for RH. It independently verifies the explicit growth-parameter algebra from the released source, including the accumulated exponents and factor 26. These are reductions and conditional consequences, not the missing arithmetic construction or square-root estimate.

## Files

- RH_Arithmetic_Theta_Completion.pdf — readable manuscript.
- RH_Arithmetic_Theta_Completion.tex — editable LaTeX source.
- EVIDENCE_LEDGER.md — status, hypotheses and source links for the workstreams.
- PROOF_OBLIGATIONS.md — concrete mathematical tasks and completion conditions.
- SOURCE_COVERAGE.md and SOURCE_INDEX.json — indexed corpus and actual inspection boundaries.
- check_identities.py, requirements.txt and CHECK_REPORT.json — exact finite algebra, a positive singular Gram control, and negative controls.
- REVIEW.md — independent internal mathematical review and resulting corrections.
- SHA256SUMS — file integrity checksums.

## Reproduce

The finite algebra checker requires Python 3 and SymPy:

```sh
python3 check_identities.py
```

Compile the manuscript with a working LaTeX installation, for example:

```sh
latexmk -pdf RH_Arithmetic_Theta_Completion.tex
```

The checker verifies finite identities and controls only. It does not validate the analytic arguments, the historical certificate corpus, or the external Lean development. The mathematical proofs and their dependencies must be read.

## Attribution and release boundary

The historical research is attributed to Jude Gomila with AI-assisted work and internal review. Classical criteria and external claims are separately cited. No claim of novelty is made for standard positivity, interpolation or Mellin arguments. The external theorem cannot be relabeled as an independently completed proof by importing its RH endpoint.

This is ready to circulate as a **research manuscript and conditional route**, subject to the explicit review limitations. It is not ready to announce as a proof of RH. No external publication or message has been sent by preparing this package.
