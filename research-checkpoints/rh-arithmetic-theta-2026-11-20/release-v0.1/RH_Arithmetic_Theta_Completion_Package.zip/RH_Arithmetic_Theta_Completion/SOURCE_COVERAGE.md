# Source coverage and inspection boundaries

Prepared 20 November 2026 for **The Twin-Ladder Weil Form and an Arithmetic Theta Completion Route**, a conditional research manuscript. This ledger records what was located, what was read, and what was checked. It is not a certificate of RH or of the complete historical corpus.

## Coverage at a glance

| Corpus | Coverage recorded | Boundary |
|---|---:|---|
| MathExplorer pull requests | 62 metadata records, PRs 1–62 | PR descriptions were inventoried; entire PR contents were not uniformly read or reverified. |
| PR61 fleet directory | 315 immediate entries: 304 lane directories and 11 files | Immediate directory inventory, not a recursive review of every artifact. |
| Selected pinned project source files | 54 files with source URLs and inspection notes | Selected result, audit, synthesis and obstruction content; review depth varies explicitly. |
| Earlier manuscripts | 4 resolved manuscripts with recorded excerpts | Excerpts only; none is marked as read in full. |
| New finite checker | 10 exact finite checks, reported PASS | Finite algebra and controls only; no RH or external Lean verification. |
| Past conversation context | Accessible retrieved context | Not an exhaustive review or export of all past chats. |

The companion `SOURCE_INDEX.json` contains every one of the 62 PR records and 315 immediate PR61 entries, including all 304 lane names, pinned identities and canonical URLs. Full PR bodies and Library transport payloads are deliberately omitted.

## Meaning of the status labels

| Label | Meaning |
|---|---|
| `indexed` | Identity, metadata, or path inventoried; does not mean the contents were read or proved. |
| `read` | Relevant source content read for this synthesis; does not certify every dependency or calculation. |
| `read_excerpt` | Only the explicit recorded excerpt was read; the full document was not read. |
| `reviewed_for_scope` | Selected mathematical claims and hypotheses compared with their arguments and/or internal audit, with limitations recorded. Internal review is not external peer review. |
| `current_core_checked` | New manuscript arguments received internal mathematical review, and specified finite identities/controls were executed. This does not verify RH, all historical sources, or the external Lean project. |

A file called `REFEREE.md` records a project internal audit. Its title does not establish journal peer review or independent formal verification. A selected file can be reviewed for the scope of its claim without every computation or cited dependency being rerun. Directory entries remain labelled `indexed` even when selected files within them were read.

## Pinned project checkpoints

| PR | Pinned head | Role in the synthesis |
|---|---|---|
| [#4](https://github.com/judegomila/mathexplorer/pull/4) | `2b5a8878d181d4f699d356b887ad9ce4137f647b` | Earlier workstream integration and a de Bruijn–Newman candidate audit; metadata context, not validation of the candidate bound. |
| [#7](https://github.com/judegomila/mathexplorer/pull/7) | `cd997dcdc4aeddba251e7b87b8531e986b516dd3` | Fail-closed Newman-bound research checkpoint; metadata context, not a newly certified bound. |
| [#40](https://github.com/judegomila/mathexplorer/pull/40) | `e6ed49358d9b430cdf4a8406214523916f63e776` | Theta–Fisher and zeta-sphere evidence context; finite/conditional evidence remains separately graded. |
| [#48](https://github.com/judegomila/mathexplorer/pull/48) | `499528b487e3249c5a35602f83343aaa53cec848` | Exact residual energy and the compensated prime-forcing target. |
| [#49](https://github.com/judegomila/mathexplorer/pull/49) | `1de63e68375adb60b39ea7fdbe7d7b048b30ceea` | Torus heat flow and a collective-zero certificate with a remaining global condition. |
| [#50](https://github.com/judegomila/mathexplorer/pull/50) | `146ce77aa8407e912ed54c73e30664d86936c253` | Fourth-stage residual energy and head–tail conditions. |
| [#55](https://github.com/judegomila/mathexplorer/pull/55) | `c617017e3a90562cd828e58ffc71b03afab128cc` | Reported six-node positivity and fixed analytic/certificate dependencies; no all-order induction. |
| [#56](https://github.com/judegomila/mathexplorer/pull/56) | `29d8f6f88250d976d4a45f6e0df0b6698bf46a16` | Klein/annulus local-to-global and operator-duality conditions. |
| [#57](https://github.com/judegomila/mathexplorer/pull/57) | `d6c92b38079762d65f71776a4efe4a3348f7f810` | Moving zero channels and certificates over specified finite ranges. |
| [#58](https://github.com/judegomila/mathexplorer/pull/58) | `97a732d54156e119627627e2b80090d63bfa9a29` | Exact identification of the all-order residual target with the Weil form and RH; Pick audit. |
| [#59](https://github.com/judegomila/mathexplorer/pull/59) | `bad3cbe3be3643cf13f21a12f17d57f85f8c4760` | Geometric lane result/audit reconciliation; operator, parity, modular and heat-flow limitations. |
| [#60](https://github.com/judegomila/mathexplorer/pull/60) | `a4b2b400018d228bd31448007b09e6b38779341c` | Stepanov/Bombieri transplant, induction attempts and arithmetic countercontrols. |
| [#61](https://github.com/judegomila/mathexplorer/pull/61) | `753fdc475c85ce347b6994d561919ffdf7b6815a` | 304 indexed research lanes, including the latest metaplectic and higher-rank work. |
| [#62](https://github.com/judegomila/mathexplorer/pull/62) | `fd26dc305c43a9a7f8a7f69abb67cb78f60dfe0f` | Finite topological zero certificates and explicit global obstructions. |

The complete metadata list includes earlier corrective PRs as well as positive results. Titles containing words such as “prove”, “verified”, or “certificate” are preserved as source titles; those words are not independent endorsements by this index.

## Specific paths that matter to the comparison

All paths below are pinned to the commit in the corresponding source link. Full paths and inspection notes are retained in the JSON index.

| Source | Inspection and mathematical boundary |
|---|---|
| [PR48: theta-schur-kernels-2026-11-09/theta_schur_residual_energy_20261109.md](https://github.com/judegomila/mathexplorer/blob/499528b487e3249c5a35602f83343aaa53cec848/rigorous/theta-schur-kernels-2026-11-09/theta_schur_residual_energy_20261109.md) | **read**. The all-order compensated prime-forcing inequality is a target equivalent to RH, not an independently proved estimate. |
| [PR55: theta-third-preservation-2026-11-11/theta_third_preservation_global_20261111.md](https://github.com/judegomila/mathexplorer/blob/c617017e3a90562cd828e58ffc71b03afab128cc/rigorous/theta-third-preservation-2026-11-11/theta_third_preservation_global_20261111.md) | **read**. Reports strict six-node positivity for distinct positive real nodes under the fixed earlier analytic proofs and certificate dependencies. No arbitrary-order induction follows. |
| [PR58: eq48/RESULT.md](https://github.com/judegomila/mathexplorer/blob/97a732d54156e119627627e2b80090d63bfa9a29/research-checkpoints/rh-push-2026-11-16/equivalence-and-pick/eq48/RESULT.md) | **reviewed_for_scope**. Identifies the residual target exactly with the Weil form and its all-order positivity with RH. A uniform strict relative margin is not supplied. |
| [PR58: eq48/REFEREE.md](https://github.com/judegomila/mathexplorer/blob/97a732d54156e119627627e2b80090d63bfa9a29/research-checkpoints/rh-push-2026-11-16/equivalence-and-pick/eq48/REFEREE.md) | **reviewed_for_scope**. Identifies the residual target exactly with the Weil form and its all-order positivity with RH. A uniform strict relative margin is not supplied. |
| [PR60: ff-transplant/RESULT.md](https://github.com/judegomila/mathexplorer/blob/a4b2b400018d228bd31448007b09e6b38779341c/research-checkpoints/rh-push-2026-11-16/direct-attacks/ff-transplant/RESULT.md) | **read**. Explicitly studies Stepanov-Bombieri and Hodge-index mechanisms. The proposed number-field transplant stops at an unproved growth estimate for a two-by-two shifted form. |
| [PR60: pick-induction/RESULT.md](https://github.com/judegomila/mathexplorer/blob/a4b2b400018d228bd31448007b09e6b38779341c/research-checkpoints/rh-push-2026-11-16/direct-attacks/pick-induction/RESULT.md) | **read**. Investigates induction and arithmetic/multiplicativity controls; the missing preservation step is not established. |
| [PR61: ap-squares-rallis/RESULT.md](https://github.com/judegomila/mathexplorer/blob/753fdc475c85ce347b6994d561919ffdf7b6815a/research-checkpoints/rh-push-2026-11-16/fleet-lanes/ap-squares-rallis/RESULT.md) | **reviewed_for_scope**. Equivariant norm realization and mixing obstruction; compact/definite targets, suitable Hecke or Casimir evolution, source-side insertion, and truncated/noncovariant constructions remain open. |
| [PR61: ap-squares-rallis/REFEREE.md](https://github.com/judegomila/mathexplorer/blob/753fdc475c85ce347b6994d561919ffdf7b6815a/research-checkpoints/rh-push-2026-11-16/fleet-lanes/ap-squares-rallis/REFEREE.md) | **reviewed_for_scope**. Equivariant norm realization and mixing obstruction; compact/definite targets, suitable Hecke or Casimir evolution, source-side insertion, and truncated/noncovariant constructions remain open. |
| [PR61: res-point-spectrum-square/REFEREE.md](https://github.com/judegomila/mathexplorer/blob/753fdc475c85ce347b6994d561919ffdf7b6815a/research-checkpoints/rh-push-2026-11-16/fleet-lanes/res-point-spectrum-square/REFEREE.md) | **reviewed_for_scope**. Residual alternatives to the mixing obstruction. Fixed-level finite-dimensional and GL2 restrictions do not exclude all growing-rank theta-lift constructions; broader claims contain internal-review qualifications. |
| [PR61: c14-theta-orthogonal-metaplectic-eigenobject/RESULT.md](https://github.com/judegomila/mathexplorer/blob/753fdc475c85ce347b6994d561919ffdf7b6815a/research-checkpoints/rh-push-2026-11-16/fleet-lanes/c14-theta-orthogonal-metaplectic-eigenobject/RESULT.md) | **reviewed_for_scope**. Weight-1/2 metaplectic Eisenstein candidate; vanishing square first moment does not remove the decisive second-moment poles. Odd-prime propagation needs a separate 2-adic input. |
| [PR61: c14-theta-orthogonal-metaplectic-eigenobject/REFEREE.md](https://github.com/judegomila/mathexplorer/blob/753fdc475c85ce347b6994d561919ffdf7b6815a/research-checkpoints/rh-push-2026-11-16/fleet-lanes/c14-theta-orthogonal-metaplectic-eigenobject/REFEREE.md) | **reviewed_for_scope**. Weight-1/2 metaplectic Eisenstein candidate; vanishing square first moment does not remove the decisive second-moment poles. Odd-prime propagation needs a separate 2-adic input. |
| [PR61: c20-u6ab-rank2-metaplectic-eigenobject-verdict/RESULT.md](https://github.com/judegomila/mathexplorer/blob/753fdc475c85ce347b6994d561919ffdf7b6815a/research-checkpoints/rh-push-2026-11-16/fleet-lanes/c20-u6ab-rank2-metaplectic-eigenobject-verdict/RESULT.md) | **reviewed_for_scope**. Latest GL3/GL4 and double-cover study; the double-cover argument and a required truncated norm remain incomplete. No required zeta estimate is established. |
| [PR61: c20-u6ab-rank2-metaplectic-eigenobject-verdict/REFEREE.md](https://github.com/judegomila/mathexplorer/blob/753fdc475c85ce347b6994d561919ffdf7b6815a/research-checkpoints/rh-push-2026-11-16/fleet-lanes/c20-u6ab-rank2-metaplectic-eigenobject-verdict/REFEREE.md) | **reviewed_for_scope**. Latest GL3/GL4 and double-cover study; the double-cover argument and a required truncated norm remain incomplete. No required zeta estimate is established. |
| [PR61: c12-depth-aspect-height-transfer/REFEREE.md](https://github.com/judegomila/mathexplorer/blob/753fdc475c85ce347b6994d561919ffdf7b6815a/research-checkpoints/rh-push-2026-11-16/fleet-lanes/c12-depth-aspect-height-transfer/REFEREE.md) | **reviewed_for_scope**. Countercontrols to explicit termwise depth-to-height character approximations, within stated ranges; not a universal obstruction to arithmetic transfer. |
| [PR61: c12-heat-tied-family-open-cell/REFEREE.md](https://github.com/judegomila/mathexplorer/blob/753fdc475c85ce347b6994d561919ffdf7b6815a/research-checkpoints/rh-push-2026-11-16/fleet-lanes/c12-heat-tied-family-open-cell/REFEREE.md) | **reviewed_for_scope**. Finite countercontrols to specific tied-weight family interpretations; not a no-go theorem for every common-family or character-averaged construction. |
| [PR61: n4-char-one-stepanov/REFEREE.md](https://github.com/judegomila/mathexplorer/blob/753fdc475c85ce347b6994d561919ffdf7b6815a/research-checkpoints/rh-push-2026-11-16/fleet-lanes/n4-char-one-stepanov/REFEREE.md) | **reviewed_for_scope**. A characteristic-one multiplicity attempt in a specified max-plus dictionary. Local factorization and degree bounds constrain that dictionary, not every possible Stepanov transplant. |
| [PR61: b-alpoge-furman/RESULT.md](https://github.com/judegomila/mathexplorer/blob/753fdc475c85ce347b6994d561919ffdf7b6815a/research-checkpoints/rh-push-2026-11-16/fleet-lanes/b-alpoge-furman/RESULT.md) | **reviewed_for_scope**. Earlier work on a positive proportion of simple critical-line zeros; this source predates and is not the current RH announcement. |
| [PR61: sq-krein-index/RESULT.md](https://github.com/judegomila/mathexplorer/blob/753fdc475c85ce347b6994d561919ffdf7b6815a/research-checkpoints/rh-push-2026-11-16/fleet-lanes/sq-krein-index/RESULT.md) | **read**. This later lane claims a stronger zero-count/inertia conclusion. That claim is not independently validated or used in the current core; it must not be described as absent merely because PR59 lacked it. |
| [PR62: obstruction/POSITIVE_QUARTET_OBSTRUCTION.md](https://github.com/judegomila/mathexplorer/blob/fd26dc305c43a9a7f8a7f69abb67cb78f60dfe0f/rigorous/topological-zero-certificates-2026-11-16/obstruction/POSITIVE_QUARTET_OBSTRUCTION.md) | **reviewed_for_scope**. Exact positive-kernel deformation with an off-axis quartet is a countercontrol to positivity/symmetry-only arguments. |
| [PR62: analysis/cutoff_compactness_and_tail_obstruction.md](https://github.com/judegomila/mathexplorer/blob/fd26dc305c43a9a7f8a7f69abb67cb78f60dfe0f/rigorous/topological-zero-certificates-2026-11-16/analysis/cutoff_compactness_and_tail_obstruction.md) | **reviewed_for_scope**. Compactness prevents a proposed identity-relative uniform tail gap; the obstruction has a specified operator setting. |

This source trail corrects an account based only on the earlier geometric visualizations: the later program did investigate Rallis-style realizations, Hecke structure, a metaplectic eigenobject, definite/compact alternatives and higher-rank objects. Those explorations are relevant overlap with the announcement. Their recorded obstructions and missing estimates remain part of the record. In particular, a mixing-flow no-go theorem does not exclude every definite-target arithmetic theta lift.

The new manuscript uses the historical material to locate the unresolved interface. It separately derives its analytic reduction, rather than treating finite numerical success, a positive-factorization wish, or a broad no-go headline as a missing proof step.

## Older manuscript coverage

The line ranges below describe the text returned by the Library read operation. They are excerpt bounds in that extraction, not a claim that the full original was inspected. Each record explicitly reports that more text remained.

| Manuscript | Stable identity | Excerpt read | Use |
|---|---|---|---|
| [gomila-zeta-twin-ladder-permutation-architecture.tex](https://chatgpt.com/library?file_id=libfile_ce8fb8b39cbc819186e35affea68e3a1&account_id=personal) | `libfile_ce8fb8b39cbc819186e35affea68e3a1` | Lines 1–110 of 1651 extracted lines | Prime-power frequencies, completion data, and signed commutator errors; excerpt-only lineage evidence. |
| [twin_ladder_v73_wigner_bridge.pdf](https://chatgpt.com/library?file_id=libfile_254c4cea9db0819197787c9f50ff7dad&account_id=personal) | `libfile_254c4cea9db0819197787c9f50ff7dad` | Lines 1–150 of 1538 extracted lines | Exact correlation/Wigner identities are distinguished from the unproved nonlocal positivity step. |
| [bridge_shear_vortex_positivity.tex](https://chatgpt.com/library?file_id=libfile_45bd1fbffcf481918939d4c18afd8b43&account_id=personal) | `libfile_45bd1fbffcf481918939d4c18afd8b43` | Lines 1–125 of 769 extracted lines | Exact shear/vortex identities and a finite theta-truncation obstruction; excerpt-only scope. |
| [Gomila_Supersymmetric_Kramers_Wannier_RH_Proof_Stage_Audit.tex](https://chatgpt.com/library?file_id=libfile_1da8ef9fde088191afd4ba91e49be666&account_id=personal) | `libfile_1da8ef9fde088191afd4ba91e49be666` | Lines 65–174 of 1047 extracted lines | Arithmetic Gram-approximation completion condition and warning that an unspecified positive factorization is tautological. |

## External announcement and released source

The [four-page announcement](https://alpo.ge/remark.pdf) was read for its claim and outline. The [independent verification project](https://github.com/Deicyde/riemann-hypothesis) was inspected to distinguish source statements from a completed full proof replay.

The original source mirror is pinned at `40e56bab026552e089d7afcfeff08d2defb9c005`. The verifier reports archive SHA-256:

`9631b4f020199e580ba86178cb56c6e9b09f690c2369a80dc4334aa93f49c7fc`

**Hash provenance:** this is the archive hash reported by the external verifier README. The archive was not independently reassembled or hashed in this task. It is not a locally recomputed integrity result.

| Pinned source file | Content inspected and dependency boundary |
|---|---|
| [StatementOC.lean](https://github.com/Deicyde/riemann-hypothesis/blob/40e56bab026552e089d7afcfeff08d2defb9c005/src/Formalism/StatementOC.lean) | Normalization and formal targets, including Sz and Gz. |
| [CharFamily.lean](https://github.com/Deicyde/riemann-hypothesis/blob/40e56bab026552e089d7afcfeff08d2defb9c005/src/Development/AutomorphicArithmetic/DedekindLFunctions/CharFamily.lean) | Finite admissible character families and positive weights; nonprincipal characters or the modulus-one character. |
| [ZeroFreeOfRpowWindow.lean](https://github.com/Deicyde/riemann-hypothesis/blob/40e56bab026552e089d7afcfeff08d2defb9c005/src/Development/AutomorphicArithmetic/DedekindLFunctions/LandauTheorems/ZeroFreeOfRpowWindow.lean) | Multiplicative-window source statement; the current full-ray argument does not independently prove this theorem. |
| [poleData.lean](https://github.com/Deicyde/riemann-hypothesis/blob/40e56bab026552e089d7afcfeff08d2defb9c005/src/Development/AutomorphicArithmetic/DedekindLFunctions/LandauTheorems/poleData.lean) | Pole multiplicities and noncancellation in the source normalization. |
| [GlobalTheoremInputs.lean](https://github.com/Deicyde/riemann-hypothesis/blob/40e56bab026552e089d7afcfeff08d2defb9c005/src/Formalism/SharpRestriction/GlobalTheoremInputs.lean) | LinkS off-diagonal, diagonal-defect and dimension-control obligations under explicit comparability; no proved identification with the project Schur residual. |
| [GrowthBoundGivesRiemannHypothesis.lean](https://github.com/Deicyde/riemann-hypothesis/blob/40e56bab026552e089d7afcfeff08d2defb9c005/src/Formalism/SizeWindowBrackets/GrowthBoundGivesRiemannHypothesis.lean) | Exact SizeWindows and GrowthSizeBound statements inspected. Their downstream real-variable inequality is independently derived and internally reviewed in Proposition 5.4; existence of the arithmetic data, balance inequality and total error estimate remains open here. |

The complete Lean development was not built here, and its full dependency graph was not independently verified. At preparation on 20 November 2026, the inspected verification project had not reported a successful full replay. This is a dated observation. A source scan, a compiling target proposition, and a successful verification-harness smoke test have different evidentiary meanings from checking the entire proof.

The source multiplicative-window theorem remains an explicitly labelled external statement. The current manuscript proves a full-ray sufficient criterion and does not silently substitute that easier statement for the window theorem. The arithmetic theta Gram construction/comparison is still open.

## Current checks and what they do not cover

The new analytic core received internal mathematical review of the sparse Pick accumulation argument, its quantifiers, the Gram-limit transfer, the exact gamma/pole/prime normalization, the prime tail, and the Mellin/noncancellation argument. This is internal review of a research draft, not external peer review or formal verification.

The accompanying checker reports the following exact finite checks:

- Cayley-Pick congruence: exact symbolic identity; PASS.
- gamma square factorization: exact symbolic identity; PASS.
- pole term includes negative norm: exact symbolic identity; PASS.
- paired Hadamard contribution: exact symbolic identity; PASS.
- prime-tail integral antiderivative: exact symbolic identity; PASS.
- ramp Mellin factor: exact symbolic identity; PASS.
- Mellin normalization removes pole at one: exact Laurent calculation; PASS.
- positive control including singular PSD matrix: exact rational-complex Gram identity; PASS.
- off-axis quartet fails third prefix: exact negative rational witness; PASS.
- singular Schur range-condition control: exact counterexample; PASS.

These checks do not establish an all-order arithmetic comparison, re-execute every historical interval certificate, or validate the external Lean project. Finite topology/heat-flow evidence is retained with its finite scope. Historical Newman-bound candidates retain their stated conditional or unverified dependencies.

## Conversation coverage and release hygiene

Accessible personal-context search and returned historical context helped orient the source review. There is no claim to have retrieved, read, or exported every past conversation. Recollections supply context; pinned mathematical statements and their hypotheses govern the evidence ledger.

The JSON index contains canonical GitHub, announcement, classical-reference and native Library links. It omits full PR bodies, signed download URLs, credentials, and Library transport metadata. Counts, unique PR numbers, unique directory paths, commit formats, URL forms and credential/signature patterns were checked during generation.

The release should be read as a program-wide synthesis with an explicit analytic completion interface. An unconditional RH proof would require the still-missing arithmetic input and a validated, much smaller dependency graph.
