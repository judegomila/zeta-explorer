#!/usr/bin/env python3
"""Exact checks for the manuscript's algebra and its negative controls.

These checks do not verify RH, the infinite-dimensional analytic proofs,
historical theta certificate suites, or the external Lean development.
Requires SymPy. Run: python3 check_identities.py
"""
from pathlib import Path
import json
import sympy as s

checks = []
def exact(name, expr):
    reduced = s.factor(s.together(expr))
    assert reduced == 0, (name, reduced)
    checks.append({"name": name, "kind": "exact symbolic identity", "passed": True})

p, q, lam, h = s.symbols('p q lam h', positive=True)
lp, lq = s.symbols('lp lq', positive=True)
wp, wq = (lp-1)/(lp+1), (lq-1)/(lq+1)
ap, aq = (p-1)/(p+1), (q-1)/(q+1)
exact('Cayley-Pick congruence', (1-wp*wq)/(1-ap*aq)
      -(p+1)/(lp+1)*(lp+lq)/(p+q)*(q+1)/(lq+1))
exact('gamma square factorization',
      (p/(lam*(lam+p))+q/(lam*(lam+q)))/(p+q)
      -(1+2*p*q/(lam*(p+q)))/((p+lam)*(q+lam)))
exact('pole term includes negative norm',
      (1/(p-h)+1/(q-h))/(p+q)
      -1/((p-h)*(q-h))+2*h/((p-h)*(q-h)*(p+q)))
rho = s.symbols('rho')
exact('paired Hadamard contribution',
      (2*p/(p*p-rho*rho)+2*q/(q*q-rho*rho))/(p+q)
      -1/((p+rho)*(q-rho))-1/((p-rho)*(q+rho)))
X, delta = s.symbols('X delta', positive=True)
bound = X**(-delta)*(s.log(X)/delta+1/delta**2)
exact('prime-tail integral antiderivative',
      s.diff(bound,X)+s.log(X)*X**(-1-delta))
z, m = s.symbols('z m', positive=True)
# Termwise integral at n=m, expressed via its elementary primitive.
term_integral = m**(-z)*(1/(z-1)-1/z)
exact('ramp Mellin factor', term_integral-m**(-z)/(z*(z-1)))
u, gamma, c = s.symbols('u gamma c')
principal = (1/u-gamma+c*u)/((1+u)*u)-1/u**2+(1+gamma)/u
series = s.series(principal,u,0,1).removeO()
assert not series.has(u**-1) and not series.has(u**-2)
checks.append({"name":"Mellin normalization removes pole at one", "kind":"exact Laurent calculation", "passed":True})

# Positive test: F(z)=z^2+1 has all zeros on the imaginary axis.
rates = [1+s.Rational(1,j+1) for j in range(1,5)]
def pick_matrix(f, n):
    logder=s.diff(f,z)/f
    xs=rates[:n]
    return s.Matrix([[(logder.subs(z,x)+logder.subs(z,y))/(x+y)
                      for y in xs] for x in xs])
good=pick_matrix(z*z+1,4)
# An explicit two-feature Gram, also valid when the four-by-four matrix is singular.
feat=s.Matrix([[1/(x-s.I),1/(x+s.I)] for x in rates])
assert (good-feat*feat.conjugate().T).applyfunc(s.simplify)==s.zeros(4)
assert good.rank()==2
checks.append({"name":"positive control including singular PSD matrix", "kind":"exact rational-complex Gram identity", "passed":True})

# Negative test: real-even, positive F and positive log derivative on x>0,
# but roots are +/-1/4 +/- i. Its third prefix detects the obstruction.
bad=((z-s.Rational(1,4))**2+1)*((z+s.Rational(1,4))**2+1)
P=pick_matrix(bad,3)
assert P[:1,:1].det()>0 and P[:2,:2].det()>0 and P.det()<0
A=P[:2,:2]; col=P[:2,2]
w=(-A.inv()*col).col_join(s.Matrix([1]))
neg=s.factor((w.T*P*w)[0])
assert neg==-s.Rational(54686,17364111375)
checks.append({"name":"off-axis quartet fails third prefix", "kind":"exact negative rational witness", "passed":True,
               "vector":[str(t) for t in w], "quadratic_value":str(neg)})

# Omitting the range condition makes the pseudoinverse criterion false.
sing=s.Matrix([[0,1],[1,1]])
assert sing.det()==-1 and (s.Matrix([[-1,1]])*sing*s.Matrix([-1,1]))[0]<0
checks.append({"name":"singular Schur range-condition control", "kind":"exact counterexample", "passed":True})

report={"status":"PASS", "checks":checks,
        "scope":"Finite exact algebra and synthetic controls only; no RH or external-formalization verification.",
        "sympy_version":s.__version__}
out=Path(__file__).with_name('CHECK_REPORT.json')
out.write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({"status":report['status'],"checks":len(checks),"report":str(out),"scope":report['scope']},indent=2))
