# Internal review of the arithmetic theta completion manuscript

Version 0.1 · 20 November 2026 · Jude Gomila research synthesis

## Review conclusion

The manuscript contains complete arguments for its stated analytic reductions, relative to identified classical inputs. Separate AI review passes examined the mathematical core and the external-source interface. They found no load-bearing defect in those arguments. This is internal mathematical review, not a formal verification or an independent human referee report.

The arithmetic comparison in Open Problem 6.1 remains unproved. Consequently the package must not be described as an unconditional proof of RH. No amount of successful algebra checking changes that status.

## Mathematical review

| Component | What was checked | Result |
|---|---|---|
| Completed zeta and theta normalization | Centering, factor of one half, evenness, real-axis positivity and derivative factor | Consistent |
| Weil form on exponential tests | Hadamard pair algebra, conjugation convention, decay on the zero strip and absolute convergence | Argument accepted in internal review |
| Signed arithmetic form | Digamma anchor, gamma squares, pole contribution and the negative pole norm | Signs and factors agree |
| Residual form | Stieltjes differential, integration by parts and boundary decay for rates greater than one half | Correct |
| Prime truncation | Correlation bound, decreasing integral majorant for integer X at least 3, operator-norm estimate | Correct for each fixed finite test space |
| Sparse Pick criterion | Cayley congruence, semidefinite Nevanlinna–Pick interpolation, Montel subsequence, interior accumulation and the identity F′ = HF | No zero-free assumption smuggled into the forward implication |
| Strictness under RH | Nonzero rational transform cannot vanish at infinitely many distinct zeros | Correct for distinct rates |
| Asymptotic Gram transfer | Order of quantifiers and the fixed-size limit | No uniformity in dimension or positive spectral gap needed |
| Singular Schur criterion | Range condition and pseudoinverse defect | Both conditions retained |
| Scalar Mellin transform | Ramp integral, cancellation at one and residue at a zeta zero | Correct |
| One-sided full-ray estimate | Compact initial interval, initial transform convergence, Landau singularity principle, real-axis regularity and noncancellation | Sufficient implication proved for either fixed sign |
| Source growth-parameter algebra | Division by the positive balance coefficient, four error quotients, exponents 2, 21/8 and 9/8, and the final factor 26 | Independently derived and reviewed; existence of arithmetic data remains open |
| External window theorem | Character admissibility, positive weights, fixed family, window quantifiers and distinction from full-ray theorem | Source statement only; not internally reproved |
| Rallis obstruction | Shift-closed domain, mixing hypothesis, exclusions and definite-target opening | Limited scope retained |

## Corrections incorporated after review

1. The front matter now distinguishes results proved in this manuscript from the imported multiplicative-window theorem.
2. The character family has positive moduli; each member must be nonprincipal or the unique character of modulus one. Arbitrary principal characters of larger modulus are not silently admitted.
3. The character-family, window and pole-data files have separate immutable source references.
4. The scalar proof states continuity, the elementary O(X log²(2X)) bound, positive constants and the initial domain explicitly.
5. The LinkS description uses its dimension-normalized off-diagonal scale. It does not treat the raw off-diagonal expression as an absolute small error or identify it with a project Schur coupling.
6. The right-translation operator and shift-closed domain in the mixing obstruction are specified.
7. The arithmetic Gram construction must not use RH or the positivity it is meant to prove.
8. The historical account records the later sq-krein-index claim as unrefereed and unvalidated in this synthesis, rather than incorrectly claiming that no such assertion exists.
9. Finite certificates, polynomial orders, Pick node counts and other hierarchies are not conflated. Bounds using published verified zeros are not counted as new zero information.

## Reproducible finite checks

`check_identities.py` uses exact SymPy arithmetic and writes `CHECK_REPORT.json`. All ten checks passed with SymPy 1.14.0:

1. Cayley–Pick congruence.
2. Gamma square factorization.
3. Pole factorization, including its negative norm term.
4. Paired Hadamard contribution.
5. Prime-tail antiderivative.
6. Ramp Mellin factor.
7. Cancellation of the apparent pole at one.
8. A positive singular Gram control with F(z) = z² + 1.
9. An even real polynomial with positive first two prefixes and a negative third prefix, including an exact rational witness.
10. A singular Schur counterexample showing that the range condition cannot be omitted.

The checks do not verify limits, analytic continuation, an infinite family of inequalities, or RH. Those claims must be assessed from their written proofs and hypotheses.

## Scope not verified

- The complete external Lean project was not built or replayed here. The inspected independent checker did not yet report a successful full Comparator run.
- The historical repository's entire certificate corpus was not rerun.
- The 304 indexed research-lane directories were not all independently proof-checked.
- Source inventory is not equivalent to exhaustive access to every past conversation.
- Reported external archive hashes were not recomputed by downloading and reassembling the original archive.
- No originality or priority claim is made for the standard positivity, interpolation, Mellin or Landau arguments.

## Document verification

The manuscript was compiled from the accompanying LaTeX source. Cross-references and citations were resolved, and the rendered pages were visually inspected. The final build had no LaTeX overfull boxes or unresolved-reference warnings. This verifies presentation, not the missing arithmetic estimate.

## Publication boundary

The present release can accurately be described as a research synthesis, exact analytic reductions and a conditional arithmetic completion route. Removing the open-status label requires a noncircular proof of the stated comparison or another sufficient arithmetic estimate, followed by review of its actual dependencies. The current mathematical review does not authorize changing that label.
