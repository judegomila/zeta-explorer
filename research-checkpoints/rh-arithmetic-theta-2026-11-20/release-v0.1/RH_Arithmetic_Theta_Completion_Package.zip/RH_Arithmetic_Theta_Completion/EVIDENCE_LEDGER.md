# Evidence ledger

**Package:** *The Twin-Ladder Weil Form and an Arithmetic Theta Completion Route*  
**Author:** Jude Gomila  
**Review date:** 20 November 2026  
**Conclusion:** This package supplies exact analytic reductions and an explicit arithmetic completion problem. It does not contain an unconditional proof of the Riemann hypothesis.

## 1. Status vocabulary and review scope

| Label | Meaning in this package |
|---|---|
| **PROVED HERE** | A complete argument appears in the accompanying manuscript, relative to its identified classical inputs. This label is not a claim of external peer review, formal verification, or novelty. |
| **PROJECT RESULT** | A pinned historical project source states the result and its hypotheses. A source's internal referee or certificate status is recorded separately. The historical suites have not all been rerun for this synthesis. |
| **EXTERNAL INPUT** | A published classical result used with its hypotheses, or a theorem from an external finite computation. These are explicitly distinguished from project computations. |
| **EXTERNAL SOURCE STATEMENT** | A literal statement or definition inspected in the announced proof's released source. Reading it does not establish that its entire dependency chain compiles or is valid. |
| **DIAGNOSTIC / UNREFEREED** | A numerical observation, an interim lane, or an assertion without the required review. It is not promoted to a proved input. |
| **OPEN** | A construction, comparison, estimate, or identification that remains to be proved. |
| **REFUTED SUFFICIENT CONDITION** | A proposed shortcut fails under specified hypotheses. This does not refute RH or every possible repair of the route. |

The source inventory records all 62 accessible MathExplorer PR descriptions and their head commits, together with 315 immediate entries, including 304 lane directories, in PR 61. The principal syntheses and selected result/referee files relevant to this comparison were read. Four earlier manuscripts and relevant local mathematical checkpoints were also inspected. This is broad source coverage, not independent line-by-line verification of all 304 lanes or all previous conversations. The accompanying `SOURCE_COVERAGE.md` and `SOURCE_INDEX.json` give the detailed coverage record.

## 2. Results proved in the present manuscript

The fixed normalization is

\[
F(w)=\xi(1/2+w),\qquad L(w)=F'(w)/F(w),\qquad
P_{ij}=\frac{L(x_i)+L(x_j)}{x_i+x_j},\quad x_i>1/2.
\]

For distinct rates and complex coefficients, put

\[
v_b(t)=\sum_j b_j e^{-x_jt},\quad
V_b(z)=\sum_j\frac{b_j}{z+x_j},\quad
Q_L(v_b)=b^*Pb.
\]

| ID | Status and statement | Dependency and limitation |
|---|---|---|
| A1 | **PROVED HERE:** the zero-side identity is \(Q_L(v)=\sum_\rho V(\rho)\overline{V(-\bar\rho)}\), with centered zeros, multiplicities and absolute convergence. The Mellin test is \(f(y)=y^{-1/2}v(-\log y)1_{(0,1]}(y)\). | The even Hadamard product and elementary partial fractions give the identity. Under RH it becomes a sum of absolute squares; without RH it is a signed form. |
| A2 | **PROVED HERE:** the complete gamma, pole and prime expression equals the same \(Q_L\). | The logarithmic derivative and prime series are used only where \(\Re(w)>1/2\). Both pole terms, including the negative pole norm, are retained. This reproduces the PR 48/58 normalization. |
| A3 | **PROVED HERE:** if the primes are truncated at integer \(X\ge3\), then \(\|P_n-P_{X,n}\|\le r_n(X)\to0\) for fixed rates and fixed \(n\), with the explicit bound in the manuscript. | This is a truncation estimate, not a positivity estimate. |
| A4 | **PROVED HERE:** all finite prefix matrices on the single sequence \(x_j=1+1/(j+1)\) are PSD if and only if RH. | Finite Nevanlinna–Pick interpolation, Montel compactness and the identity theorem are classical inputs. The accumulating point lies inside the right half-plane. Every finite size is still required. |
| A5 | **PROVED HERE:** if, for each fixed \(n\), \(P_{X,n}-G_{X,n}\succeq-\epsilon_{X,n}I\), \(G_{X,n}\succeq-\eta_{X,n}I\), and \(\epsilon_{X,n}+\eta_{X,n}\to0\), then RH. | This is a transfer theorem. No such arithmetic family with the required comparison is constructed in this package. No uniformity in \(n\) or positive spectral gap is needed. |
| A6 | **PROVED HERE:** a block \(\begin{pmatrix}A&u\\u^*&d\end{pmatrix}\), with \(A\succeq0\), is PSD exactly when \(u\in\operatorname{ran}A\) and \(d-u^*A^\dagger u\ge0\). | The range condition is indispensable for singular prefixes. The manuscript supplies the completion-of-the-square proof. |
| A7 | **PROVED HERE:** the weighted Mangoldt discrepancy \(G_\zeta(X)\) has the stated Mellin transform, whose residue at a nontrivial zero \(\rho_s\) is \(-m_{\rho_s}/[\rho_s(\rho_s-1)]\ne0\). | The elementary main terms remove the pole at 1. This is a transform identity, not a square-root estimate. |
| A8 | **PROVED HERE:** for either one fixed sign, a one-sided bound \(\pm G_\zeta(X)\le C_\varepsilon X^{1/2+\varepsilon}\) for every sufficiently large real \(X\), for every \(\varepsilon>0\), implies RH. | The proof uses Landau's nonnegative-transform principle. It does not establish the bound and does not prove the separate external multiplicative-window theorem. |
| A9 | **PROVED HERE:** the explicit source size window, error bound and balance inequality imply \(G\le x^{1/2+(C+3)\varepsilon}\). | Proposition 5.4 independently checks the four error quotients and the final factor 26. It does not construct arithmetic data satisfying the assumptions; for an RH deduction, \(C\) must be fixed as \(\varepsilon\downarrow0\). |

The exact algebra checker covers the gamma/pole identities, Cayley congruence, generalized Schur boundary and a rational off-axis negative control. These checks test algebra and guard against false inferences; they do not verify the historical interval-certificate corpus or the external formal proof. See `CHECK_REPORT.json` for the actual recorded run.

## 3. Pinned project sources

All paths in this section are relative to `judegomila/mathexplorer` at the stated commit. A draft PR's presence in the inventory does not imply it was merged or externally reviewed.

### 3.1 Exact arithmetic and finite Pick progression

| PR | Immutable head | Principal source path | Recorded contribution and boundary |
|---|---|---|---|
| [47](https://github.com/judegomila/mathexplorer/pull/47) | `7e6d01d9dae527a5785ed31d770cd4b8acd38e17` | `rigorous/theta-interpolation-2026-11-08/theta_exact_pick_bridge_20261108.md` | Exact arithmetic/Suzuki bridge and conditional all-stage interpolation closure. All later actual-xi pivots were open. An auxiliary concave kernel has a certified negative four-node determinant. |
| [48](https://github.com/judegomila/mathexplorer/pull/48) | `499528b487e3249c5a35602f83343aaa53cec848` | `rigorous/theta-schur-kernels-2026-11-09/theta_schur_residual_energy_20261109.md` | Exact residual-energy target, especially equation (21), and the third finite Pick stage. The residual sign at every stage was not proved. |
| [50](https://github.com/judegomila/mathexplorer/pull/50) | `146ce77aa8407e912ed54c73e30664d86936c253` | `rigorous/theta-fourth-stage-2026-11-09/theta_rational_residual_20261109.md` | Fourth finite stage and exact rational residual recurrence; separates head-null Schur structure from the missing sign. |
| [51](https://github.com/judegomila/mathexplorer/pull/51) | `afdac28948ab084e80214c31ef72c9520d943760` | `rigorous/theta-ratio-convexity-2026-11-10/README.md` | Global ratio signs and the full comparison-class conditions. A class-membership theorem is not an all-depth preservation theorem. |
| [52](https://github.com/judegomila/mathexplorer/pull/52) | `a24e261deae84bf2a06b6c33a7fbdfe95db2b803` | `rigorous/theta-preservation-2026-11-10/README.md` | First canonical preservation and a rigorous obstruction for a broader kernel class. |
| [53](https://github.com/judegomila/mathexplorer/pull/53) | `5d64d45acf37f4957a8f65c036b502e1b49292d0` | `rigorous/theta-second-preservation-2026-11-11/README.md` | Second full preservation and strict five-node real Pick positivity. |
| [54](https://github.com/judegomila/mathexplorer/pull/54) | `7556c563be6845444d33b187d1ab8dc984664795` | `rigorous/theta-third-gate-2026-11-11/theta_third_gate_synthesis_20261111.md` | Third-origin and next-source origin conditions; all-order total nonnegativity for an auxiliary compensation kernel. At this checkpoint, the two global next-source inequalities remained open, so the Pick order was still five. |
| [55](https://github.com/judegomila/mathexplorer/pull/55) | `c617017e3a90562cd828e58ffc71b03afab128cc` | `rigorous/theta-third-preservation-2026-11-11/theta_third_preservation_global_20261111.md` | Closes those two global mixed-source signs for all positive anchors and spatial points, including coalescences; third full preservation yields strict six-node real Pick positivity. Arbitrary-depth preservation remains open. |
| [58](https://github.com/judegomila/mathexplorer/pull/58) | `97a732d54156e119627627e2b80090d63bfa9a29` | `research-checkpoints/rh-push-2026-11-16/equivalence-and-pick/eq48/RESULT.md` and `REFEREE.md` | Identifies the PR 48 residual exactly with the Weil functional and Suzuki screw form. The all-order residual condition is RH-equivalent, subject to the corrected Schur-prefix formulation. |

**PR 55 hypothesis and verification detail.** The theorem concerns the actual complete theta kernel and its specified canonical pairs. The two mixed signs are \(\partial_a\partial_t\log f_H>0\) and \(\partial_a\partial_t\log f_P>0\) on the entire positive domain, with fixed strict origin conditions. It reports 11 primary gates, 137 exact symbolic checks, 70 exact tail checks and 4,472 interval-cell evaluations at 512 bits, together with full infinite-theta and spatial-tail controls. Earlier PR 53/54 dependencies were explicitly declared and not all rerun in that checkpoint. These are **PROJECT RESULT** claims with internal review, not new verification performed by this synthesis. Six positive rates are finite-order progress; they do not imply the seventh or every later order.

**PR 58 corrections retained.** The exact Weil identity survived its internal referee pass. A nested-prefix statement formulated only using inverse Schur residuals must require every prefix to be positive definite, or must use the pseudoinverse together with the range condition. Otherwise it becomes undefined after a singular prefix. The refutation of a uniform fractional gamma-energy margin applies to the full exponential test class; it does not by itself refute a margin restricted to actual Schur residuals.

The `pick/NEXT_STAGE.md` lane in the same PR records finite real-node positivity through size 12 using a Loewner splitting, Dobsch–Donoghue and externally verified zeros. Its referee gives positive definiteness through size 7 as written and positive semidefiniteness for sizes 8–12; using the appropriate number of distinct zero factors repairs strictness, but that version of the code was not rerun. These finite stages use published verified-height input and provide no new zero-location information.

### 3.2 Polynomial, spectral and topological stages

**PR 40 — PROJECT RESULT / EXTERNAL INPUT.** Head `e6ed49358d9b430cdf4a8406214523916f63e776`, [PR 40](https://github.com/judegomila/mathexplorer/pull/40). Relevant paths under `research-checkpoints/zeta-sphere-theta-fisher-bridge-2026-11-02/evidence/v33-continuation/` are:

- `theta_correlated_local_v1/FULL_SHIFT_DEGREE10.md`;
- `sparse_exception_bridge_nov03/VERIFIED_ZERO_FINITE_DEGREE.md`;
- `theta_correlated_local_audit/VERIFIED_ZERO_FINITE_DEGREE_AUDIT.md`.

The checkpoint reports a direct degree-10 positive-cutoff certificate for \(0\le a\le1/2\), \(0\le H_{\rm cut}\le1/8\), and a separate global-cutoff polynomial result through degree 30,000,000,000 using Platt–Trudgian's published verification through height \(3\cdot10^{12}\) and explicit project tail estimates. The published zero computation was not rerun. The complex-polynomial version uses \(|p|^2\), not \(p^2\). These are finite-degree results, and the cutoff and spectral-height variables have different meanings.

The odd degree-11 direct enclosure was inconclusive in the PR 40 checkpoint, not negative. PR 58's later `deg11/` record reports success on 16 slabs after increasing the tail subdivision to 16,000 cells, for positive cutoff; that later computation is explicitly unaudited and supplies nothing new at zero cutoff. An older H9 gap belonged to an older proof chain and must not be represented as a current project-wide degree ceiling. Derivative degrees, numbers of Pick nodes, odd Mellin Taylor orders and verified zero heights must never be combined into one progress count.

**PR 27 — integration evidence.** Head `72a4b9e7ed4f46fee1e21f54f7b9138c26a86663`, [PR 27](https://github.com/judegomila/mathexplorer/pull/27), preserves the signed-complement, whole-even certificate, denominator-repair and spectral-head modules with their focused source lineage. Its build and publication audits establish reproducibility and integration, not a global complement inequality. The historical \(X=16.1\) seventh-power surrogate was a failed sufficient bound, not actual negativity; later reflection-even endpoint repair is a distinct result.

**PR 62 — PROJECT RESULT.** Head `fd26dc305c43a9a7f8a7f69abb67cb78f60dfe0f`, directory `rigorous/topological-zero-certificates-2026-11-16/`, [PR 62](https://github.com/judegomila/mathexplorer/pull/62). It records certified complete counts in finite bands, independently checked bounded cages, negative controls, and a positive-kernel deformation carrying an off-line quartet while preserving any prescribed finite family of bounded strict certificates. The deformation changes the exact zeta arithmetic. It is a counterexample to an inference from a finite list of structural tests, not a counterexample to RH. All-height exhaustion and every-degree positivity remain open.

### 3.3 PR 60: direct arithmetic attacks and controls

Pin: `a4b2b400018d228bd31448007b09e6b38779341c`, [PR 60](https://github.com/judegomila/mathexplorer/pull/60). Base path: `research-checkpoints/rh-push-2026-11-16/direct-attacks/`. These lanes are **UNREFEREED** unless an actual referee file is identified; the PR explicitly disclaims a new RH bound.

| Source | Finding | Correct implication |
|---|---|---|
| `ff-transplant/RESULT.md` | Studies Hodge and Stepanov–Bombieri mechanisms and isolates a number-field shifted two-by-two estimate. The desired response has polynomial growth in logarithmic scale; the available arithmetic estimates retain exponential growth. | The project had already reached a function-field-inspired arithmetic bottleneck. It had not supplied the multiplicity amplification or its required number-field estimate. |
| `pick-induction/RESULT.md` | Records the first finite preservation stages and an Arb-certified negative Davenport–Heilbronn confluent Pick direction at order 149, anchor 1. | Failure occurs **by that order for that configuration**; this is not a proof of a globally minimal failing order. Earlier passing numerical matrices do not establish arbitrary order. |
| `pick-induction/RESULT.md`, Theorem R | An admissible nonzero perturbation of the prime weights destroys the all-order statement. | Such perturbations generally destroy the functional equation. This does not refute a theorem using the full exact arithmetic and functional equation together. |
| `weil-onesided/RESULT.md` | Gives exact local-factor expressions and an Euler-blind positivity cone; per-prime brackets remain signed. Nonnegative von Mangoldt weights give an upper bound in the indicated nonnegative cone. | The required sign is not supplied by coefficient positivity. A claimed nonclosability obstruction concerns its enlarged domain, not automatically the finite exponential class alone. |
| `bootstrap/RESULT.md` | No mechanism in that lane improves an assumed zero-free half-plane; shifted-product controls remain. | It is a failure of the proposed bootstrap, not an impossibility theorem for every arithmetic route. |

### 3.4 PR 61: the relevant automorphic and signature continuation

Pin: `753fdc475c85ce347b6994d561919ffdf7b6815a`, [PR 61](https://github.com/judegomila/mathexplorer/pull/61). Every path below is under `research-checkpoints/rh-push-2026-11-16/fleet-lanes/`.

| Source pair or synthesis | Recorded content and its scope |
|---|---|
| `h-metaplectic-spin/RESULT.md`, `REFEREE.md`; `SYNTHESIS_GEOMETRIC_ARITHMETIC.md` | Hecke and metaplectic eigenrelations, including corrections to the prime-power recurrence and the geodesic stabilizer. These are arithmetic structure, not an all-order positivity theorem. |
| `n2-rank2-eisenstein-kernel/RESULT.md`, `REFEREE.md` | Rank-two positivity is stronger than the tested rank-one conditions. The lane records a precise obstruction and does not furnish the full positive kernel. |
| `ap-squares-rallis/RESULT.md`, `REFEREE.md`; `SYNTHESIS_AUTOMATIC_POSITIVITY.md` | A norm realization of the Weil form covariant under a **mixing** unitary evolution is obstructed. The referee explicitly rejects a claim that this excludes every Rallis or theta-lift realization. |
| `c14-theta-orthogonal-metaplectic-eigenobject/RESULT.md`, `REFEREE.md` | The November 19 continuation constructs a weight-one-half eigenobject with a zeta-dependent vanishing square row. The first-moment vanishing does not remove the decisive second-moment poles. |
| `c20-u6ab-rank2-metaplectic-eigenobject-verdict/RESULT.md`, `REFEREE.md` | The November 20 continuation examines rank-two, GL3, GL4 and double-cover candidates. The double-cover argument and a required truncated norm remain incomplete. |
| `res-identity-solenoid/RESULT.md`, `REFEREE.md`; `SYNTHESIS_POSITIVITY_RESIDUALS.md` | The audited trace-form theorem is for finite zero clusters and polynomial tests. The full bridge/trace-form identification in that lane is argued by matching formulas, not proved. |
| `sq-krein-index/RESULT.md`; fleet `README.md` | **Later broader claim exists:** this lane asserts a broader inertia statement, counting distinct zeros. The index labels it **unrefereed**. This synthesis has not validated that theorem and does not use it. It would be inaccurate to say the project contains no broader inertia claim. |

The Rallis correction is directly relevant to the announced definite-group route. Compact targets, targets compact at infinity, Hecke/Casimir evolution with pure-point spectrum, source-side test insertion, and noncovariant or truncated constructions are not excluded by that mixing argument. An unexcluded class is not a constructed comparison map. A positive Petersson or Rallis norm is not yet the project's signed Weil form; measures, test insertion, pole terms and local factors must match.

## 4. Earlier manuscripts and local checkpoint findings

The four recovered manuscripts supply continuity of the program, with the review boundaries in `SOURCE_COVERAGE.md`:

- **17 July 2026, Wigner bridge v73:** exact shifted-correlation identities, divisor defects and obstructions to pointwise positivity. The outstanding issue was nonlocal positivity or a canonical-system realization.
- **15 August 2026, supersymmetric Kramers–Wannier proof-stage audit:** exact algebraic identities and an arithmetic Gram-approximation completion condition. An unspecified positive factorization would restate the desired positivity.
- **24 August 2026, twin-ladder permutation architecture:** prime-power frequencies, completion/reflection data and signed commutator errors. Convergence-half-plane trace identities alone do not locate all zeros.
- **2 November 2026, bridge shear and vortex positivity:** exact phase-current/shear identities and a finite-theta-truncation obstruction. Every naive fixed theta-index truncation breaks the full modular endpoint cancellations and has eventually negative shear. The complete infinite theta tail is essential.

The following local sources were inspected for the audit. Their results retain their own hypotheses; they are not newly certified by this package:

| Local source | Retained finding |
|---|---|
| `/workspace/scratch/98b8676fdded/math-quotient-checkpoint/rigorous/klein-annulus-coupling-2026-11-14/README.md` | A faithful Klein quotient preserves the normalized coupling \(\|D^{-1/2}BE^{-1/2}\|\) and the Schur target. The annulus reference has an exact mode coupling, but an intertwiner to the actual theta operator is not supplied. Positive entries or a constant-phase cone do not prove arbitrary oscillatory-test PSD. |
| Same Klein/annulus checkpoint | Small finite odd Taylor/node certificates and an all-order odd criterion are recorded. The majorant loses the odd Mellin sector; compact cutoff operators do not acquire a constant positive lower gap on their infinite-dimensional tail. |
| `/workspace/scratch/02813a8088bd/projective_rh/domination_20261114/theta_route.md` and `audit.md` | Finite-window structural agreement can survive off-axis perturbations. A uniform relative energy gap is unavailable in the analyzed setting. All-order local kernel PSD is a much stronger condition than finitely many scalar samples. |
| `/workspace/scratch/cc69f9774609/rh_contours/arithmetic_attack/full_theta_curvature.md` | Complete-theta curvature and a specified finite positive band are established in the recorded argument. A finite band is not a global matrix sign; truncating the theta sum loses endpoint cancellations. |
| `/workspace/scratch/4306f4e52879/reconciled_bridge_claims_20261108.md` | Reconciles older H8/H9/H10 chains with later PR 40 results. It prevents treating an obsolete finite-stage gap as the latest theorem or confusing different degree conventions. |

Geometric quotient charts, sphere pictures, torus symmetries and phase-current identities are useful exact descriptions. They do not make the indefinite coupling contractive. A passive realization, an attractive zero flow, or a global heat-flow confinement theorem requires additional hypotheses and proof.

## 5. External announcement and formal-source boundary

Alpöge's [announcement](https://alpo.ge/remark.pdf), inspected 20 November 2026, claims RH and a generalized result through repeated automorphic theta lifts and multiplicity amplification. It is not treated here as independently verified.

The inspected external original-source mirror is pinned at commit:

`40e56bab026552e089d7afcfeff08d2defb9c005`

Repository: [Deicyde/riemann-hypothesis](https://github.com/Deicyde/riemann-hypothesis).

Reported original archive SHA-256:

`9631b4f020199e580ba86178cb56c6e9b09f690c2369a80dc4334aa93f49c7fc`

The archive hash is **reported by the checker and was not locally recomputed**. The full external Lean project was not built here. At the November 20 status check, the independent verification project inspected had not reported a successful full proof replay. This is a dated observation, not a prediction of the eventual result.

| Pinned external source path, relative to `src/` | What was inspected | Status |
|---|---|---|
| `Formalism/StatementOC.lean` | The exact `Sz`/`Gz` weighted Mangoldt discrepancy normalization. | **EXTERNAL SOURCE STATEMENT**; its elementary Mellin identity is separately proved in the manuscript. |
| `Development/AutomorphicArithmetic/DedekindLFunctions/CharFamily.lean` | A fixed finite character family, positive moduli and strictly positive real weights; each character nonprincipal or modulus one. | **EXTERNAL SOURCE STATEMENT** with its admissibility conditions retained. |
| `Development/AutomorphicArithmetic/DedekindLFunctions/LandauTheorems/ZeroFreeOfRpowWindow.lean` | `Deduction.zeroFree_of_rpow_window`: a uniform one-sided estimate on arbitrarily late multiplicative windows implies the corresponding zero-free region. | **EXTERNAL SOURCE STATEMENT**; the full dependency chain is not validated in this package. The full-ray proof here does not establish it. |
| `Development/AutomorphicArithmetic/DedekindLFunctions/LandauTheorems/poleData.lean` | Pole multiplicities and noncancellation for positive-weighted character families. | **EXTERNAL SOURCE STATEMENT**; the local residue calculation is also explained directly in the manuscript. |
| `Formalism/SharpRestriction/GlobalTheoremInputs.lean` | `LinkS`, including dimension-normalized off-diagonal estimates, diagonal Hilbert–Schmidt defect bounds and comparability hypotheses. | A **definition/obligation is not a proved instance**. These quantities have not been identified with the project's normalized Schur coupling. |
| `Formalism/SizeWindowBrackets/GrowthBoundGivesRiemannHypothesis.lean` | `SizeWindows` and `GrowthSizeBound`, including the exact range \(x^{1/2-\varepsilon}\le m\le x^{1/2+\varepsilon/2}\). | The downstream algebra is **PROVED HERE**; the source's arithmetic-data existence, balance and total error bounds are not established by that algebra. |

The announced automorphic theta lifts, the Jacobi theta representation of xi, and the project's canonical scalar theta reductions are three different constructions. Shared terminology is not an intertwining theorem. Importing an external endpoint that already asserts RH would make the project's equivalent criteria corollaries; it would not turn the present incomplete comparison into an independent proof.

## 6. Assessment carried forward

The project reached the correct signed arithmetic object and developed substantial exact identities, finite certificates, canonical reductions and obstruction tests around it. PR 58 is the closest direct mathematical connection to Weil positivity; PR 60 and the later PR 61 lanes show that function-field mechanisms, metaplectic structure and definite alternatives were also explored.

The missing step is a universal arithmetic sign or growth estimate. It is not a missing coordinate change or one more finite numerical check. Neither many passing finite stages nor the resemblance to the announced route measures how close that estimate is to a proof. The present manuscript makes the required interface smaller and explicit: fixed finite prefixes on one accumulating sequence suffice, with errors tending to zero separately for each prefix. The construction and estimate required to satisfy that interface remain **OPEN**.
